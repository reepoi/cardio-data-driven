function A = uplus(A)
% Intentially left empty.

%   Copyright 2008, Ewout van den Berg and Michael P. Friedlander
%   http://www.cs.ubc.ca/labs/scl/sparco
%   $Id: uplus.m 1040 2008-06-26 20:29:02Z ewout78 $


